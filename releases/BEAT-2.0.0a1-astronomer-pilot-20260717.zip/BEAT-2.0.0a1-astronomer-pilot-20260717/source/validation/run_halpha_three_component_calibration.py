#!/usr/bin/env python3
"""Controlled H-alpha three-component separation/flux-ratio calibration."""

from __future__ import annotations

import argparse
import copy
import json
import time
from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path
from typing import Any

import numpy as np

from beat.fitting import fit_spectrum
from beat.injection import (
    InjectedComponent,
    analytic_injection_spectrum,
    muse_halpha_nii_fit,
    score_recovery,
)


PROJECT = Path(__file__).resolve().parents[1]
OUTPUT = PROJECT / "validation" / "halpha_three_component_calibration"
CALIBRATION_VERSION = "controlled-triple-v1"
SEPARATIONS_KMS = (200, 300, 400)
FLUX_PATTERNS = {
    "equal": (1.0, 1.0, 1.0),
    "moderate": (1.0, 0.7, 0.5),
    "weak": (1.0, 0.5, 0.25),
}
LSF = {
    "model": "polynomial_fwhm_angstrom",
    "reference_angstrom": 7000.0,
    "scale_angstrom": 1000.0,
    "coefficients": [2.48344, -0.09746, 0.05866],
    "source": "UDF-10 WFM empirical Gaussian approximation",
    "approximation": True,
}


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def fit_config(profile: str) -> dict[str, Any]:
    if profile == "pilot":
        sampling = {
            "min_num_live_points": 60,
            "min_ess": 80,
            "dlogz": 2.0,
            "nsteps": 16,
        }
    elif profile == "tight":
        sampling = {
            "min_num_live_points": 120,
            "min_ess": 250,
            "dlogz": 0.5,
            "nsteps": 24,
        }
    else:  # pragma: no cover - argparse and tests constrain this
        raise ValueError(f"Unknown profile: {profile}")
    fit = muse_halpha_nii_fit(
        max_components=3,
        min_num_live_points=sampling["min_num_live_points"],
        min_ess=sampling["min_ess"],
        dlogz=sampling["dlogz"],
    )
    fit["sampling"].update(sampling)
    fit["lsf"] = dict(LSF)
    return fit


def definitions(realizations: int) -> list[dict[str, Any]]:
    cases = []
    for separation_index, separation in enumerate(SEPARATIONS_KMS):
        for pattern_index, (pattern, ratios) in enumerate(FLUX_PATTERNS.items()):
            for realization in range(realizations):
                noise_seed = (
                    40_000
                    + separation_index * 1000
                    + pattern_index * 100
                    + realization
                )
                components = [
                    InjectedComponent(-float(separation), 70.0, 20.0, ratios[0]),
                    InjectedComponent(0.0, 100.0, 20.0, ratios[1]),
                    InjectedComponent(float(separation), 80.0, 20.0, ratios[2]),
                ]
                cases.append(
                    {
                        "name": f"triple_sep{separation}_{pattern}_r{realization:02d}",
                        "separation_kms": separation,
                        "flux_pattern": pattern,
                        "flux_ratios": ratios,
                        "realization": realization,
                        "noise_seed": noise_seed,
                        "sampler_seed": 2_000_000 + noise_seed,
                        "components": components,
                    }
                )
    return cases


def selection_diagnostics(result: dict[str, Any]) -> dict[str, Any]:
    models = {int(model["n_components"]): model for model in result["models"]}
    comparisons = {}
    for upper in range(1, 4):
        lower = upper - 1
        if lower in models and upper in models:
            comparisons[f"delta_logz_{upper}_minus_{lower}"] = float(
                models[upper]["logz"] - models[lower]["logz"]
            )
            comparisons[f"combined_error_{upper}_minus_{lower}"] = float(
                np.hypot(models[upper]["logz_error"], models[lower]["logz_error"])
            )
    return comparisons


def run_fit(spectrum, fit: dict[str, Any], seed: int) -> tuple[dict[str, Any], float, str, str]:
    np.random.seed(int(seed))
    stdout = StringIO()
    stderr = StringIO()
    start = time.perf_counter()
    with redirect_stdout(stdout), redirect_stderr(stderr):
        result = fit_spectrum(spectrum, fit)
    return result, time.perf_counter() - start, stdout.getvalue(), stderr.getvalue()


def summarize(cases: list[dict[str, Any]]) -> dict[str, Any]:
    completed = []
    for case in cases:
        checkpoint = OUTPUT / "cases" / case["name"] / "result.json"
        if not checkpoint.exists():
            continue
        payload = json.loads(checkpoint.read_text(encoding="utf-8"))
        profile = "tight" if "tight" in payload["profiles"] else "pilot"
        item = dict(payload["profiles"][profile]["score"])
        item.update(
            {
                "name": case["name"],
                "profile": profile,
                "separation_kms": case["separation_kms"],
                "flux_pattern": case["flux_pattern"],
                "delta_logz_3_minus_2": payload["profiles"][profile][
                    "selection_diagnostics"
                ].get("delta_logz_3_minus_2"),
                "runtime_seconds": payload["profiles"][profile]["runtime_seconds"],
            }
        )
        completed.append(item)

    by_separation = {}
    for separation in SEPARATIONS_KMS:
        subset = [item for item in completed if item["separation_kms"] == separation]
        by_separation[str(separation)] = {
            "n": len(subset),
            "correct": int(sum(item["component_count_correct"] for item in subset)),
            "accuracy": (
                float(np.mean([item["component_count_correct"] for item in subset]))
                if subset else None
            ),
        }
    by_flux_pattern = {}
    for pattern in FLUX_PATTERNS:
        subset = [item for item in completed if item["flux_pattern"] == pattern]
        by_flux_pattern[pattern] = {
            "n": len(subset),
            "correct": int(sum(item["component_count_correct"] for item in subset)),
            "accuracy": (
                float(np.mean([item["component_count_correct"] for item in subset]))
                if subset else None
            ),
        }
    return {
        "calibration_version": CALIBRATION_VERSION,
        "n_planned": len(cases),
        "n_completed": len(completed),
        "component_count_accuracy": (
            float(np.mean([item["component_count_correct"] for item in completed]))
            if completed else None
        ),
        "by_separation_kms": by_separation,
        "by_flux_pattern": by_flux_pattern,
        "cases": completed,
        "interpretation": (
            "controlled pilot only; use tight reruns to audit transition cases and "
            "expand noise realizations before setting a completeness boundary"
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--realizations", type=int, default=1)
    parser.add_argument("--profile", choices=("pilot", "tight"), default="pilot")
    parser.add_argument("--only", action="append", default=[], metavar="CASE")
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args()
    if args.realizations < 1:
        parser.error("--realizations must be positive")

    all_cases = definitions(args.realizations)
    names = {case["name"] for case in all_cases}
    unknown = sorted(set(args.only) - names)
    if unknown:
        parser.error(f"unknown --only case(s): {', '.join(unknown)}")
    active_cases = [
        case for case in all_cases if not args.only or case["name"] in args.only
    ]
    OUTPUT.mkdir(parents=True, exist_ok=True)
    generation_fit = fit_config("pilot")
    inference_fit = fit_config(args.profile)

    for index, case in enumerate(active_cases, start=1):
        checkpoint = OUTPUT / "cases" / case["name"] / "result.json"
        payload = None
        if checkpoint.exists():
            payload = json.loads(checkpoint.read_text(encoding="utf-8"))
            if args.profile in payload.get("profiles", {}) and not args.no_resume:
                print(
                    f"[{index}/{len(active_cases)}] resumed {case['name']} "
                    f"({args.profile})",
                    flush=True,
                )
                continue

        spectrum, truth = analytic_injection_spectrum(
            case["name"],
            0.01,
            case["components"],
            generation_fit,
            seed=case["noise_seed"],
            noise_sigma=1.0,
            reference_line="halpha",
            independent_line_ratios={"halpha": 1.0, "nii6583": 0.7},
        )
        result, runtime, stdout, stderr = run_fit(
            spectrum,
            copy.deepcopy(inference_fit),
            case["sampler_seed"] + (500_000 if args.profile == "tight" else 0),
        )
        score = score_recovery(result, truth)
        profile_payload = {
            "fit": inference_fit,
            "result": result,
            "score": score,
            "selection_diagnostics": selection_diagnostics(result),
            "runtime_seconds": runtime,
            "sampler_stdout_tail": stdout[-4000:],
            "sampler_stderr_tail": stderr[-4000:],
        }
        if payload is None:
            payload = {
                "calibration_version": CALIBRATION_VERSION,
                "case": {
                    **case,
                    "flux_ratios": list(case["flux_ratios"]),
                    "components": [item.__dict__ for item in case["components"]],
                },
                "truth": truth,
                "profiles": {},
            }
        payload["profiles"][args.profile] = profile_payload
        write_json(checkpoint, payload)
        delta32 = profile_payload["selection_diagnostics"].get("delta_logz_3_minus_2")
        delta_text = "not reached" if delta32 is None else f"{delta32:.2f}"
        print(
            f"[{index}/{len(active_cases)}] {case['name']}: 3 -> "
            f"{result['selected_components']}; dlnZ32={delta_text}; "
            f"{args.profile}={runtime:.1f}s",
            flush=True,
        )

    summary = summarize(all_cases)
    write_json(OUTPUT / "summary.json", summary)
    write_json(
        OUTPUT / "manifest.json",
        {
            "calibration_version": CALIBRATION_VERSION,
            "separations_kms": list(SEPARATIONS_KMS),
            "flux_patterns": {key: list(value) for key, value in FLUX_PATTERNS.items()},
            "primary_peak_snr": 20.0,
            "component_sigmas_kms": [70.0, 100.0, 80.0],
            "pilot_fit": fit_config("pilot"),
            "tight_fit": fit_config("tight"),
        },
    )
    print(json.dumps(summary, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
