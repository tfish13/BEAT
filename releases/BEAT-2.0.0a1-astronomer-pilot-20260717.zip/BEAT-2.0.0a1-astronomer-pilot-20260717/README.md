# BEAT 2.0.0a1 astronomer pilot kit

BEAT (Bayesian Evidence Analysis Tool) fits zero or more Gaussian emission-line
components and selects the preferred component count using Bayesian evidence.
This pilot release supports bounded MUSE, JWST/NIRSpec IFU, and JWST/MIRI MRS
cubes, collections of 1D spectra, and survey-style FITS tables.

This is alpha software for astronomer evaluation. It is not yet a stable
`2.0.0` scientific release.

## Install without administrator privileges

Python 3.9 or newer is required. A fresh conda environment is recommended:

```bash
conda env create -f environment.yml
conda activate beat-pilot
python -m pip install wheel/beat_astro-2.0.0a1-py3-none-any.whl
beat --version
```

Alternatively, from an existing environment:

```bash
python -m pip install -r requirements.txt
python -m pip install wheel/beat_astro-2.0.0a1-py3-none-any.whl
```

Do not use `sudo`. The wheel is pure Python; Astropy, NumPy, Matplotlib,
PyYAML, and UltraNest are installed into the selected environment.

## Five-minute smoke test

The demo generates a deterministic one-component [O III] spectrum:

```bash
cd demo
python generate_demo.py
beat validate demo.yaml
beat run demo.yaml
```

Results are written to `demo/beat_demo_output/`. The first nested-sampling run
may take a minute or two depending on the computer.

## Run your own data

1. Copy the closest file from `examples/`.
2. Replace the input path or glob, redshift, bounded spatial region, lines, and
   fit window.
3. Validate before starting UltraNest:

   ```bash
   beat validate my_config.yaml
   ```

4. Review the reported pixel count, wavelength range, uncertainty scale, and
   noise correlation.
5. Run the fit:

   ```bash
   beat run my_config.yaml
   ```

Cube templates deliberately use small spatial subsets. Do not set
`allow_full_cube: true` for an initial test.

## Current scientific status

- The NIRSpec standard core recovers 16/16 zero-through-three-component test
  cases.
- A powered NIRSpec residual-noise matrix recovers 20/20 blanks and 20/20
  S/N=10 singles with no evidence flags when marginal-error calibration and
  AR(1) covariance are enabled.
- NIRSpec double/triple completeness is demonstrated but not yet powered to 20
  cases per class.
- MUSE three-component H-alpha recovery, MIRI profile-shape validation, and
  broad-line physical interpretation remain active validation areas.

Read `docs/ALPHA_TEST_REPORT.md` and
`docs/NIRSPEC_INJECTION_RECOVERY.md` before using results scientifically.

## What to send back

Please complete `PILOT_FEEDBACK.md`. For a failed or surprising fit, include:

- the configuration YAML;
- the output manifest and result JSON;
- the diagnostic plot;
- the terminal error or warning; and
- a short description of the expected line structure.

Do not redistribute proprietary or embargoed spectra without permission.

## Contents

- `wheel/`: installable BEAT package;
- `source/`: matching source code and automated tests;
- `demo/`: data generator and runnable smoke-test configuration;
- `examples/`: portable templates for supported input families;
- `docs/`: configuration and instrument guides plus validation reports;
- `PILOT_FEEDBACK.md`: structured evaluation form; and
- `CHECKSUMS.txt`: wheel checksum.

The wheel is recommended for pilot installation. To install from source:

```bash
python -m pip install ./source
```

To run the included source tests:

```bash
cd source
PYTHONPATH=src python -m unittest discover -s tests -v
```

BEAT is distributed under the BSD 3-Clause License.
