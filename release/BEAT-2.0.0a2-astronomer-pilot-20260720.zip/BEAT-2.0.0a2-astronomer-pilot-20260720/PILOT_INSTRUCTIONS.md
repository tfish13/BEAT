# Astronomer pilot instructions

Please spend approximately 60-90 minutes testing one bounded workflow. We are
testing installation, configuration, outputs, trust flags, and recovery—not
asking you to validate a full cube or survey.

## 1. Install without developer help

Use a fresh Python >=3.9 environment if practical. Install the supplied wheel,
run `beat --version`, and record your operating system, Python version, elapsed
installation time, exact commands, and any help required.

## 2. Run the packaged demo

Generate, validate, and run the demo using the commands in `README.md`. Locate
the catalog, diagnostic plot, atomic result, failure table if present, and
`run_manifest.json`. Explain in your own words what the selected component
count and evidence/trust status mean.

## 3. Run a small sample of your own data

Edit YAML only. Use approximately 5-25 spaxels or 20-100 one-dimensional
spectra, not a complete cube or survey. Choose one track:

- MUSE H-alpha+[N II] or H-beta+[O III];
- one bounded NIRSpec IFU region;
- one bounded MIRI MRS segment; or
- a small collection/table of 1D spectra.

Record whether the configuration guide was sufficient and whether the plots
and catalog answer a normal astronomy question. Do not upload restricted raw
data.

## 4. Exercise recovery

Interrupt a run and repeat the same command with resume enabled. Confirm that
completed results are retained. Also introduce one harmless error, such as a
bad path or malformed input, and report whether the message is understandable
and recovery is obvious.

## 5. Return feedback

Complete `PILOT_FEEDBACK.md`. If permitted, attach the YAML configuration,
`run_manifest.json`, `failures.csv`, terminal log, and one representative plot.
Remove local paths or target information that should not be shared.

Classify findings as:

- P0: scientifically dangerous or silently wrong result;
- P1: installation/run blocker, crash, data loss, or unusable recovery;
- P2: confusing configuration, documentation, flags, plots, or catalog;
- P3: cosmetic issue or feature request.

The pilot does not require full-cube runs, powered injection campaigns, or
proof that every selected Gaussian is a physical gas component.
