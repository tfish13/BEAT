# BEAT 2.0.0a2 astronomer pilot

This is the frozen build for the first external astronomer pilot. It is alpha
software: use the trust flags and supported-domain statements, and do not treat
an unreviewed multi-Gaussian decomposition as a physical interpretation.

## Install

No root privileges are required. In a fresh conda environment or virtual
environment, run:

```bash
python -m pip install wheel/beat_astro-2.0.0a2-py3-none-any.whl
beat --version
```

Existing environments, including `astroenv`, may also install the wheel. A
fresh environment is preferred for the installation portion of the pilot.

## Start with the packaged demo

```bash
python demo/generate_demo.py
beat validate demo/demo.yaml
beat run demo/demo.yaml --workers 1
```

Then follow `PILOT_INSTRUCTIONS.md`. Copy the nearest file in `examples/` for
your own small dataset; do not edit BEAT's Python source.

## Scientific boundaries

- MUSE: the powered H-alpha+[N II] domain and blue H-beta+[O III] LSF check are
  documented in `validation/MUSE_POWERED_VALIDATION.md`. The representative
  WFM LSF is not a dataset-matched `LSF_PROFILE`.
- NIRSpec: powered G235H results support effective component S/N >= 10 within
  the documented configurations. Weaker components are exploratory.
- MIRI: the Gaussian-equivalent LSF is supported only within the documented
  sampling, S/N, separation, and profile-mismatch limits.
- Broad H-alpha: use one broad component for routine fitting. Multiple broad
  Gaussians are not automatically physical.
- 1D surveys: streaming, multiprocessing, partial failure, and resume are
  operationally tested on synthetic SDSS-like inputs; real-SDSS scientific
  completeness has not been established.

See `RELEASE_NOTES.md`, the instrument guides, and the validation reports
before scientific use.
