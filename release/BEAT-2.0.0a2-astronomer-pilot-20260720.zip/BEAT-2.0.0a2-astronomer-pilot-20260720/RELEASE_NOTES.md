# BEAT 2.0.0a2 pilot release notes

Released: 2026-07-20

This alpha supersedes the initial `2.0.0a1` pilot bundle and freezes the build
for external astronomer testing.

## Validation completed since 2.0.0a1

- Powered MUSE H-alpha+[N II] validation: 60/60 blanks and 20/20 singles,
  doubles, and triples within the supported red domain, with passing parameter
  gates and no evidence flags.
- MUSE H-beta+[O III] blue-wavelength LSF check.
- Powered NIRSpec double/triple expansion and a conservative G235H supported
  boundary of effective component S/N >= 10.
- Bounded MIRI validation across all 12 MRS sub-bands, including representative
  short/middle/long injections and explicit profile-mismatch tests.
- Nine-spaxel NGC 1365 broad-H-alpha study, recommending one broad component
  for routine fitting.
- A 512-row synthetic SDSS-like operational regression covering streaming,
  multiprocessing, malformed rows, interruption/resume, deterministic
  provenance, and partial failure.

## Software and testing

- Evidence reliability flags and optional targeted tight reruns are retained.
- AR(1) residual covariance and empirical marginal-error calibration are
  available for validated configurations.
- The complete packaged suite contains 66 tests; all pass in the release
  environment.

## Known limitations

- The configuration schema remains unfrozen until release-candidate work.
- Supported domains are conditional on the documented configurations and
  thresholds; extrapolation is exploratory.
- The MUSE LSF is representative rather than dataset matched.
- MIRI weak/narrow components in undersampled regions require review.
- Real-SDSS scientific completeness is not validated.
- Multiple broad Gaussians must not be assigned direct physical meaning
  automatically.
