# BEAT astronomer pilot feedback

## Tester and system

- Name or anonymous identifier:
- Date:
- OS and version:
- Python and environment type:
- Instrument/input track:
- Prior involvement with BEAT: none / limited / substantial

## Installation

- Installed without help: yes / no
- Minutes required:
- Exact install command:
- `beat --version` output:
- Errors, warnings, or intervention required:

## Packaged demo

- `beat validate` completed: yes / no
- `beat run` completed: yes / no
- Could you locate the catalog, plot, result, and manifest: yes / no
- In your words, what did the selected component count and trust status mean?

## Your-data test

- Approximate number of spaxels/spectra:
- Could you configure it without changing Python: yes / no
- Most confusing configuration fields:
- Did the outputs answer a normal astronomy question: 1 / 2 / 3 / 4 / 5
- Were the trust flags and supported-domain limits clear: 1 / 2 / 3 / 4 / 5
- Any apparently incorrect or misleading scientific result:

## Recovery and failures

- Interrupt/resume preserved completed outputs: yes / no / not tested
- Deliberate failure used:
- Was the message understandable: 1 / 2 / 3 / 4 / 5
- Was recovery obvious: 1 / 2 / 3 / 4 / 5

## Findings

List each finding with severity P0/P1/P2/P3, reproduction steps, expected
behavior, and actual behavior. Attach a redacted YAML, manifest, failure table,
terminal log, and one plot when permitted.

## Overall

- Would you use this build for an exploratory analysis: yes / no / unsure
- Single most important change before beta:
- Additional comments:
